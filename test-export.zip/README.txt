H2 TANK DESIGNER - EXPORT PACKAGE
================================
Export ID: export-C-test
Generated: 2025-12-07T06:56:05.417Z

DESIGN SUMMARY
--------------
Design ID: C
Trade-off Category: recommended

Performance Metrics:
  Weight: 79.3 kg
  Cost: €13500
  Burst Pressure: 1720 bar
  Burst Ratio: 2.46
  P(failure): 6e-7
  Fatigue Life: 58000 cycles

Geometry:
  Inner Radius: 175 mm
  Outer Radius: 204 mm
  Cylinder Length: 1200 mm
  Total Length: 1560 mm
  Wall Thickness: 28.1 mm
  Internal Volume: 150.3 L

Composite Structure:
  Total Layers: 42
  Helical Layers: 18
  Hoop Layers: 24
  Fiber Volume Fraction: 0.64
  Liner Thickness: 3.2 mm

PACKAGE CONTENTS
----------------
/geometry/
  dome_profile.csv      - Isotensoid dome profile coordinates (r, z)
  dimensions.json       - Complete geometry dimensions

/manufacturing/
  layup_definition.csv  - Complete layup sequence with angles and thicknesses
  winding_sequence.txt  - Winding program instructions

/analysis/
  design_summary.json   - Key performance metrics
  stress_report.json    - Stress analysis results
  failure_analysis.json - Failure mode prediction
  thermal_analysis.json - Thermal analysis results
  reliability_analysis.json - Monte Carlo reliability results

/compliance/
  standards_compliance.json - Standards compliance status

NOTES
-----
This export package contains machine-readable data for manufacturing and analysis.
For CAD files (STEP, IGES), contact support for full engineering package.
